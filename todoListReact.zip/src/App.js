import React from "react";
import TodosList from "./TodosList";

function App() {
  return (
    <div className="App">
      <TodosList/>
    </div>
  );
}

export default App;
