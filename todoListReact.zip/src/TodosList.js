import * as React from "react";

class todosList extends React.Component{
    state={
        todos: [],
        text: ''
    }
    render(){
        return(
            <div>
                <head>
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
                          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
                          crossOrigin="anonymous"/></head>
                <body>
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
                        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
                        crossOrigin="anonymous"></script></body>
                <h1 style={{color: "blue"}}>Hello! What tasks do you have?</h1>
                <br/><br/>
                {
                    this.state.todos.length>0&&
                    <div>
                        <h3 style={{color: "blue"}}>tasks remaining: {this.state.todos.length} </h3>
                        <br/><br/>
                    </div>
                }
                {
                    this.state.todos.length==0&&
                    <div>
                        <h3 style={{color: "blue"}}>Add tasks, if you have any...</h3>
                        <br/><br/>
                    </div>
                }
                <div className="row mb-3">
                    <b htmlFor="inputEmail3" className="col-sm-1 col-form-label">New Task:</b>
                    <div className="col-sm-5">
                        <input value={this.state.text} onChange={this.textChange} className="form-control" id="inputEmail3"/>
                        <br/>
                    </div>
                </div>
                <button className={"btn btn-primary"} disabled={!this.state.text} onClick={this.addTask}> add task </button>
                {
                    this.state.todos.length>0&&
                    <button style={{ marginLeft: '.5rem' }} className={"btn btn-primary"} onClick={this.removeAllTasks}> remove all tasks</button>
                }
                <div> {this.state.todos.map((item =>{
                    return<div>
                        <br/>
                        <li style={{width: 100}} className="list-group-item list-group-item-info"
                            onClick={this.removeTask}>{item}</li>
                    </div>
                }))}
                </div>
            </div>
        )
    }
    textChange=(event)=>{
        this.setState({
            text: event.target.value
        })
    }
    addTask=()=>{
        const newTodos=this.state.todos;
        newTodos.push(this.state.text);
        this.setState({
            todos: newTodos,
            text: ''
        })
    };
    removeTask=(event)=>{
        let newTodos=this.state.todos.filter(function (item){
            return item!==event.target.innerText;
        })
        this.setState({
            todos: newTodos
        })
    }
    removeAllTasks=()=>{
        this.setState({
            todos: []
        })
    }
}
export default todosList;
